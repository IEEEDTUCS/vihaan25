(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_app__components_Navbar_jsx_c0555edc._.js", {

"[project]/src/app/_components/Navbar.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
//import { Plus } from "lucide-react";
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$GridLayout$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/_components/GridLayout.jsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const Navbar = ()=>{
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [songPlaying, setSongPlaying] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isRotated, setIsRotated] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const toggleMenu = ()=>{
        setIsOpen(!isOpen);
        setIsRotated(!isRotated);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: "relative bg-transparent text-white",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl  px-4 sm:px-6 lg:px-8",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between h-16",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex space-x-1 items-center relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center justify-center text-stone-500 text-xs font-normal font-['Orbitron'] tracking-widest",
                                    children: "VOLUME"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/Navbar.jsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center justify-center text-stone-500 text-xs font-normal font-['Orbitron'] tracking-widest",
                                    children: songPlaying ? '<ON>' : '<OFF>'
                                }, void 0, false, {
                                    fileName: "[project]/src/app/_components/Navbar.jsx",
                                    lineNumber: 26,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        width: '100%',
                                        height: '100%',
                                        marginLeft: 160,
                                        transform: 'rotate(180deg)',
                                        marginTop: 20
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 19,
                                                height: 0,
                                                left: 141,
                                                top: 19,
                                                position: 'absolute',
                                                transform: 'rotate(270deg)',
                                                transformOrigin: 'top left',
                                                outline: '1.50px #8F7E77 solid',
                                                outlineOffset: '-0.75px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 28,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 9,
                                                height: 9,
                                                left: 131,
                                                top: 14,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                borderRadius: 9999,
                                                border: '1.12px #8F7E77 solid'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 29,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 15,
                                                height: 0,
                                                left: 123,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 30,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 15,
                                                height: 0,
                                                left: 58,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 31,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 5,
                                                height: 0,
                                                left: 102,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 32,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 5,
                                                height: 0,
                                                left: 37,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 33,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 15,
                                                height: 0,
                                                left: 91,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 34,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 15,
                                                height: 0,
                                                left: 26,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 35,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 9,
                                                height: 0,
                                                left: 74,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 36,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            style: {
                                                width: 9,
                                                height: 0,
                                                left: 9,
                                                top: 10,
                                                position: 'absolute',
                                                transform: 'rotate(180deg)',
                                                transformOrigin: 'top left',
                                                outline: '1px #8F7E77 solid',
                                                outlineOffset: '-0.50px'
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 37,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/_components/Navbar.jsx",
                                    lineNumber: 27,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/_components/Navbar.jsx",
                            lineNumber: 24,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: " md:block hidden xl:absolute xl:right-8 ",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: " flex items-baseline lg:relative xl:relative md:absolute md:top-6 lg:top-0 md:right-8 lg:right-0  xl:left-0.5   relative ",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: " lg:block hidden ",
                                        style: {
                                            marginRight: 160
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 19,
                                                    height: 0,
                                                    left: 141,
                                                    top: 19,
                                                    position: 'absolute',
                                                    transform: 'rotate(270deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1.50px #8F7E77 solid',
                                                    outlineOffset: '-0.75px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 46,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 9,
                                                    height: 9,
                                                    left: 131,
                                                    top: 14,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    borderRadius: 9999,
                                                    border: '1.12px #8F7E77 solid'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 47,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 15,
                                                    height: 0,
                                                    left: 123,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 48,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 15,
                                                    height: 0,
                                                    left: 58,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 49,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 5,
                                                    height: 0,
                                                    left: 102,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 50,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 5,
                                                    height: 0,
                                                    left: 37,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 51,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 15,
                                                    height: 0,
                                                    left: 91,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 52,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 15,
                                                    height: 0,
                                                    left: 26,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 53,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 9,
                                                    height: 0,
                                                    left: 74,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 54,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                style: {
                                                    width: 9,
                                                    height: 0,
                                                    left: 9,
                                                    top: 10,
                                                    position: 'absolute',
                                                    transform: 'rotate(180deg)',
                                                    transformOrigin: 'top left',
                                                    outline: '1px #8F7E77 solid',
                                                    outlineOffset: '-0.50px'
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 55,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/_components/Navbar.jsx",
                                        lineNumber: 45,
                                        columnNumber: 16
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex justify-evenly space-x-0 md:space-x-4 border-white  ",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden md:block",
                                                style: {
                                                    textAlign: 'center',
                                                    justifyContent: 'center',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    color: '#8F7E77',
                                                    fontSize: 12,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: '400',
                                                    letterSpacing: 2.40,
                                                    wordWrap: 'break-word'
                                                },
                                                children: "TEAM"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 60,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden md:block",
                                                style: {
                                                    textAlign: 'center',
                                                    justifyContent: 'center',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    color: '#8F7E77',
                                                    fontSize: 12,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: '400',
                                                    letterSpacing: 2.40,
                                                    wordWrap: 'break-word'
                                                },
                                                children: "JUDGES"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 61,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden md:block",
                                                style: {
                                                    textAlign: 'center',
                                                    justifyContent: 'center',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    color: '#8F7E77',
                                                    fontSize: 12,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: '400',
                                                    letterSpacing: 2.40,
                                                    wordWrap: 'break-word'
                                                },
                                                children: "FAQ"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 63,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden md:block",
                                                style: {
                                                    textAlign: 'center',
                                                    justifyContent: 'center',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    color: '#8F7E77',
                                                    fontSize: 12,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: '400',
                                                    letterSpacing: 2.40,
                                                    wordWrap: 'break-word'
                                                },
                                                children: "TRACK"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 64,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "hidden md:block",
                                                style: {
                                                    textAlign: 'center',
                                                    justifyContent: 'center',
                                                    display: 'flex',
                                                    flexDirection: 'column',
                                                    color: '#8F7E77',
                                                    fontSize: 12,
                                                    fontFamily: 'Orbitron',
                                                    fontWeight: '400',
                                                    letterSpacing: 2.40,
                                                    wordWrap: 'break-word'
                                                },
                                                children: "TRACK"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 65,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "-right-[1vw] absolute top-2 ",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    width: "22",
                                                    height: "599",
                                                    viewBox: "0 0 22 599",
                                                    fill: "none",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                        "fill-rule": "evenodd",
                                                        "clip-rule": "evenodd",
                                                        d: "M22.0004 1V1.875V12.8605H21.9847V13H20.9847V1.875H0.000366211V0.875H22.0004V1ZM22.0004 42.5124V18.7908H21.0004L21.0004 42.5124H22.0004ZM22.0004 58.3264V99.8386H21.0004L21.0004 58.3264H22.0004ZM22.0004 151.235V113.676H21.0004L21.0004 151.235H22.0004ZM22.0004 157.165V204.608H21.0004L21.0004 157.165H22.0004ZM22.0004 222.398V208.562H21.0004V222.398H22.0004ZM22.0004 228.328V256.004H21.0004L21.0004 228.328H22.0004ZM22.0004 275.772V259.958H21.0004V275.772H22.0004ZM22.0004 281.702V293.562H21.0004V281.702H22.0004ZM22.0004 315.306V297.516H21.0004L21.0004 315.306H22.0004ZM22.0004 319.26V348.912H21.0004L21.0004 319.26H22.0004ZM22.0004 366.702V350.888H21.0004V366.702H22.0004ZM22.0004 370.656V372.634H21.0004V370.656H22.0004ZM22.0004 390.424V378.564H21.0004L21.0003 390.424H22.0004ZM22.0004 400.308V447.75H21.0003L21.0003 400.308H22.0004ZM22.0004 467.518V449.728H21.0003V467.518H22.0004ZM22.0004 471.472V479.378H21.0003V471.472H22.0004ZM21.0003 598.858H22.0004V483.332H21.0003L21.0003 598.858Z",
                                                        fill: "#8F7E77"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/_components/Navbar.jsx",
                                                        lineNumber: 70,
                                                        columnNumber: 21
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/_components/Navbar.jsx",
                                                    lineNumber: 69,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                                lineNumber: 68,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/_components/Navbar.jsx",
                                        lineNumber: 58,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                lineNumber: 43,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/Navbar.jsx",
                            lineNumber: 42,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "-mr-2 flex md:hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                                whileTap: {
                                    rotate: 45
                                },
                                animate: {
                                    rotate: isRotated ? 45 : 0
                                },
                                transition: {
                                    type: "spring",
                                    stiffness: 300
                                },
                                onClick: toggleMenu,
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    width: "40",
                                    height: "40",
                                    viewBox: "0 0 40 40",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "8.65106",
                                            y: "8.28872",
                                            width: "22.6979",
                                            height: "22.6979",
                                            stroke: "#A59188",
                                            strokeWidth: "0.867306"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 90,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "20.0828",
                                            y: "10.0394",
                                            width: "13.6332",
                                            height: "13.6332",
                                            transform: "rotate(45 20.0828 10.0394)",
                                            stroke: "#A59188",
                                            strokeWidth: "0.867306"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                                            x: "20.0828",
                                            y: "2.8862",
                                            width: "23.7493",
                                            height: "23.7493",
                                            transform: "rotate(45 20.0828 2.8862)",
                                            stroke: "#A59188",
                                            strokeWidth: "0.867306"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "20.0866",
                                            x2: "20.0866",
                                            y2: "5.49854",
                                            stroke: "#A59188",
                                            strokeWidth: "0.173461"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 93,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "20.0866",
                                            y1: "33.7768",
                                            x2: "20.0866",
                                            y2: "39.2753",
                                            stroke: "#A59188",
                                            strokeWidth: "0.173461"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 94,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "39.6375",
                                            y1: "19.7244",
                                            x2: "34.139",
                                            y2: "19.7244",
                                            stroke: "#A59188",
                                            strokeWidth: "0.173461"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 95,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "5.86087",
                                            y1: "19.7244",
                                            x2: "0.362328",
                                            y2: "19.7244",
                                            stroke: "#A59188",
                                            strokeWidth: "0.173461"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "15.2599",
                                            y1: "16.5",
                                            x2: "24.7401",
                                            y2: "16.5",
                                            stroke: "#AC9990"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 97,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "15.2599",
                                            y1: "22.8202",
                                            x2: "24.7401",
                                            y2: "22.8202",
                                            stroke: "#AC9990"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                                            x1: "15.2599",
                                            y1: "19.6601",
                                            x2: "24.7401",
                                            y2: "19.6601",
                                            stroke: "#AC9990"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/_components/Navbar.jsx",
                                            lineNumber: 99,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/_components/Navbar.jsx",
                                    lineNumber: 89,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/_components/Navbar.jsx",
                                lineNumber: 83,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/_components/Navbar.jsx",
                            lineNumber: 82,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/_components/Navbar.jsx",
                    lineNumber: 22,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/_components/Navbar.jsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_components$2f$GridLayout$2e$jsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/_components/Navbar.jsx",
                lineNumber: 107,
                columnNumber: 18
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/_components/Navbar.jsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
};
_s(Navbar, "FivAhDTwiwzCzM+lGoojz26wy/s=");
_c = Navbar;
const __TURBOPACK__default__export__ = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_app__components_Navbar_jsx_c0555edc._.js.map