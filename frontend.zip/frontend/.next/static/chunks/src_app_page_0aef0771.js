(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_0aef0771.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_0aef0771.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_283aa15a._.js",
    "static/chunks/node_modules_0971baba._.js",
    "static/chunks/src_app__components_7b5d4f79._.js"
  ],
  "source": "dynamic"
});
