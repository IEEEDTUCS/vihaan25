(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_70aa5a83.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_70aa5a83.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_297da82e._.js",
    "static/chunks/src_app_8e8bfa1e._.js",
    "static/chunks/node_modules_ed4c9d2c._.js"
  ],
  "source": "dynamic"
});
