(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_9ba7633f.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_9ba7633f.js",
  "chunks": [
    "static/chunks/src_app_a79fafe4._.js"
  ],
  "source": "dynamic"
});
