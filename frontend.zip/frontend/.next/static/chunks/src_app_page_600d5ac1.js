(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_600d5ac1.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_600d5ac1.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_79ad38ec._.js",
    "static/chunks/src_app_4481cb25._.js",
    "static/chunks/node_modules_ed4c9d2c._.js"
  ],
  "source": "dynamic"
});
