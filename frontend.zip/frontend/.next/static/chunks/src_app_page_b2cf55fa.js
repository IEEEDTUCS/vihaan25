(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_b2cf55fa.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_b2cf55fa.js",
  "chunks": [
    "static/chunks/src_app_a3b73508._.js",
    "static/chunks/node_modules_framer-motion_dist_es_components_AnimatePresence_718850ad._.js"
  ],
  "source": "dynamic"
});
