(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_Sponsors_page_jsx_ea1109d5._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_Sponsors_page_jsx_ea1109d5._.js",
  "chunks": [
    "static/chunks/src_app__components_Sponsor_jsx_314dbcf8._.js"
  ],
  "source": "dynamic"
});
