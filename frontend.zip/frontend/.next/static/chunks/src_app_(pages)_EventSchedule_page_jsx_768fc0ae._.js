(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_EventSchedule_page_jsx_768fc0ae._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_EventSchedule_page_jsx_768fc0ae._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_da3e0fb0._.js",
    "static/chunks/_e556d181._.js"
  ],
  "source": "dynamic"
});
