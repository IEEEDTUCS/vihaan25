(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(pages)_EventSchedule_page_jsx_3eb2a96c._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(pages)_EventSchedule_page_jsx_3eb2a96c._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cd1ebfe0._.js",
    "static/chunks/_c075f791._.js"
  ],
  "source": "dynamic"
});
