(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_3eb2a96c.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_3eb2a96c.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_510c0e58._.js",
    "static/chunks/node_modules_2f905106._.js",
    "static/chunks/src_app__components_7b5d4f79._.js"
  ],
  "source": "dynamic"
});
