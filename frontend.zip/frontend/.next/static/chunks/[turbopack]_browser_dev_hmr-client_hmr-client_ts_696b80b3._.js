(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_696b80b3._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_696b80b3._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_61dcf9ba._.js"
  ],
  "source": "dynamic"
});
