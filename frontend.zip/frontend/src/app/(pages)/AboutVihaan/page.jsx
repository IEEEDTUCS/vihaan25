import About from "@components/AboutVihaan/About"
const page = () => {
  return (
    <>
    {/* PAGES ARE JUST TO TEST COMPONENTS */}
    <About/>
    </>
  );
};

export default page;