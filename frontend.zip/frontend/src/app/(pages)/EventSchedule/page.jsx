import DotButton from "@/app/_components/ui/Button";
import EventSchedule from "@components/EventSchedule/EventSchedule";

const page = () => {
  return (
    <>

    <DotButton href="https://example.com">hallo vai mic testing</DotButton>
    {/* PAGES ARE JUST TO TEST COMPONENTS */}
    <EventSchedule/>

    </>
  );
};

export default page;