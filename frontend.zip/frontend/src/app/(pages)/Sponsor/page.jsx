import React from 'react'
import Sponsor from '@/app/_components/Sponsor'
const page = () => {
  return (
    <Sponsor/>
  )
}

export default page