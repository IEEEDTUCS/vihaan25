const FAQIcon = () => {
  return (
    <div>
</div>
  )
}

export default FAQIcon;
